//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TAQ_Data_LPT : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox2;
        TTimer *TimerLEDs;
        TImage *Image1;
        TTimer *TimerValues;
        TPanel *Panel1;
        TPanel *PanelHexValues;
        TLabel *LabelData;
        TLabel *LabelStatus;
        TLabel *LabelControl_;
        TLabel *Label0x379;
        TLabel *Label0x37A;
        TLabel *LabelHexValueData;
        TLabel *LabelHexValueControl;
        TLabel *LabelHexValueStatus;
        TLabel *LabelRegisterType;
        TLabel *LabelMemoryAddress;
        TLabel *LabelHexValue;
        TMaskEdit *MaskEdit_REGISTER;
        TPanel *Panel2;
        TGroupBox *GroupBox1;
        TShape *Shape_DI_1;
        TShape *Shape_DI_2;
        TShape *Shape_DI_3;
        TShape *Shape_DI_4;
        TShape *Shape_DI_5;
        TLabel *Label_DI_1;
        TLabel *Label_DI_2;
        TLabel *Label_DI_3;
        TLabel *Label_DI_4;
        TLabel *Label_DI_5;
        TLabel *Label_Error;
        TLabel *Label_Select;
        TLabel *Label_Paper_Out;
        TLabel *Label_Busy;
        TLabel *Label_ACK;
        TPanel *Panel3;
        TGroupBox *GroupBox3;
        TShape *Shape_DO_1;
        TShape *Shape_DO_2;
        TShape *Shape_DO_3;
        TShape *Shape_DO_4;
        TShape *Shape_DO_5;
        TShape *Shape_DO_6;
        TShape *Shape_DO_7;
        TShape *Shape_DO_8;
        TShape *Shape_DO_9;
        TShape *Shape_DO_10;
        TShape *Shape_DO_11;
        TShape *Shape_DO_12;
        TLabel *Label_DO_1;
        TLabel *Label_DO_2;
        TLabel *Label_DO_3;
        TLabel *Label_DO_4;
        TLabel *Label_DO_5;
        TLabel *Label_DO_6;
        TLabel *Label_DO_7;
        TLabel *Label_DO_8;
        TLabel *Label_DO_9;
        TLabel *Label_DO_10;
        TLabel *Label_DO_11;
        TLabel *Label_DO_12;
        TLabel *Label_D2;
        TLabel *Label_D1;
        TLabel *Label_D0;
        TLabel *Label_Strobe;
        TLabel *Label_SelectPrinter;
        TLabel *Label_Reset;
        TLabel *Label_LineFeed;
        TLabel *Label_D7;
        TLabel *Label_D6;
        TLabel *Label_D5;
        TLabel *Label_D4;
        TLabel *Label_D3;
        TButton *Button_DO1;
        TButton *Button_DO2;
        TButton *Button_DO3;
        TButton *Button_DO4;
        TButton *Button_DO5;
        TButton *Button_DO6;
        TButton *Button_DO7;
        TButton *Button_DO8;
        TButton *Button_DO9;
        TButton *Button_DO10;
        TButton *Button_DO11;
        TButton *Button_DO12;
        TButton *ButtonSet;
        void __fastcall TimerLEDsTimer(TObject *Sender);
        void __fastcall MaskEdit_REGISTEREnter(TObject *Sender);
        void __fastcall ButtonSetClick(TObject *Sender);
        void __fastcall TimerValuesTimer(TObject *Sender);
        void __fastcall Button_DO1Click(TObject *Sender);
        void __fastcall Button_DO2Click(TObject *Sender);
        void __fastcall Button_DO3Click(TObject *Sender);
        void __fastcall Button_DO4Click(TObject *Sender);
        void __fastcall Button_DO5Click(TObject *Sender);
        void __fastcall Button_DO6Click(TObject *Sender);
        void __fastcall Button_DO7Click(TObject *Sender);
        void __fastcall Button_DO8Click(TObject *Sender);
        void __fastcall Button_DO9Click(TObject *Sender);
        void __fastcall Button_DO10Click(TObject *Sender);
        void __fastcall Button_DO11Click(TObject *Sender);
        void __fastcall Button_DO12Click(TObject *Sender);
private:	// User declarations
public:		// User declarations

        __fastcall TAQ_Data_LPT(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAQ_Data_LPT *AQ_Data_LPT;
//---------------------------------------------------------------------------
#endif
 