#include <vcl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <conio.h>

#pragma hdrstop
#include "Unit1.h"

//#define REGISTER 0xDE00

typedef short (_stdcall *inpfuncPtr)(short portaddr);
typedef void (_stdcall *oupfuncPtr)(short portaddr, short datum);

extern int inpout32_init(void);
extern void inpout32_unload(void);
extern short Inp32(short portaddr);
extern void Out32(short portaddr,short datum);

int B1C,B2C,B3C,B4C;
int B1D,B2D,B3D,B4D,B5D,B6D,B7D,B8D;
int B4S,B5S,B6S,B7S,B8S;
int Data,Control,Status;

int CountDO1,CountDO2,CountDO3,CountDO4,CountDO5,CountDO6,CountDO7,CountDO8,CountDO9,CountDO10,CountDO11,CountDO12;

int REGISTER;

static HINSTANCE hLib;

static inpfuncPtr inp32fp = NULL;
static oupfuncPtr oup32fp = NULL;

#pragma package(smart_init)
#pragma resource "*.dfm"
TAQ_Data_LPT *AQ_Data_LPT;

__fastcall TAQ_Data_LPT::TAQ_Data_LPT(TComponent* Owner)
        : TForm(Owner)
{
 inpout32_init();
}


int inpout32_init(void)
{
 short x;
 int i;

 /* Load the library */
 hLib = LoadLibrary("inpout32.dll");

 if (hLib == NULL)
   {
    ShowMessage("LoadLibrary Failed.\n");
    return -1;
   }

 /* Get the address of the function */

inp32fp = (inpfuncPtr) GetProcAddress(hLib, "Inp32");

 if (inp32fp == NULL)
   {
    ShowMessage("GetProcAddress for Inp32 Failed.\n");
    return -1;
   }

 oup32fp = (oupfuncPtr) GetProcAddress(hLib, "Out32");

 if (oup32fp == NULL)
   {
    ShowMessage("GetProcAddress for Oup32 Failed.\n");
    return -1;
   }
  return 0;
}


void inpout32_unload(void)
    {
     (void) FreeLibrary(hLib);

     return;
    }

/* Wrapper Functions */

short  Inp32 (short portaddr)
     {
      return (inp32fp)(portaddr);
     }

void  Out32 (short portaddr, short datum)
    {
     (oup32fp)(portaddr,datum);
    }

void __fastcall TAQ_Data_LPT::TimerLEDsTimer(TObject *Sender)
{
 short mask;
 mask = 0x40;
 int x,y;

 x = Inp32(REGISTER+1);
 y = ( ( x & mask ) >> 6 );

 if ( y == 0 )
   {
    B7S = 1;
    AQ_Data_LPT->Shape_DI_1->Brush->Color = clRed;
   }
 else
     {
      B7S = 0;
      AQ_Data_LPT->Shape_DI_1->Brush->Color = clBlack;
     }

 mask = 0x80;

 x = Inp32(REGISTER+1);
 y = ( ( x & mask ) >> 7 );

 if ( y == 0 )
   {
    B8S = 1;
    AQ_Data_LPT->Shape_DI_2->Brush->Color = clRed;
   }
 else
     {
      B8S = 0;
      AQ_Data_LPT->Shape_DI_2->Brush->Color = clBlack;
     }

 mask = 0x20;

 x = Inp32(REGISTER+1);
 y = ( ( x & mask ) >> 5 );

 if ( y == 0 )
   {
    B6S = 1;
    AQ_Data_LPT->Shape_DI_3->Brush->Color = clRed;
   }
 else
     {
      B6S = 0;
      AQ_Data_LPT->Shape_DI_3->Brush->Color = clBlack;
     }

 mask = 0x10;

 x = Inp32(REGISTER+1);
 y = ( ( x & mask ) >> 4 );

 if ( y == 0 )
   {
    B5S = 1;
    AQ_Data_LPT->Shape_DI_4->Brush->Color = clRed;
   }
 else
     {
      B5S = 0;
      AQ_Data_LPT->Shape_DI_4->Brush->Color = clBlack;
     }

 mask = 0x08;

 x = Inp32(REGISTER+1);
 y = ( ( x & mask ) >> 3 );

 if ( y == 0 )
   {
    B4S = 1;
    AQ_Data_LPT->Shape_DI_5->Brush->Color = clRed;
   }
 else
     {
      B4S = 0;
      AQ_Data_LPT->Shape_DI_5->Brush->Color = clBlack;
     }

 mask = 0x01;

 mask = 0x01;

     x = Inp32(REGISTER+2);
     y =  x & mask;

    if ( y == 0 )
       {
        B1C = 1;
        AQ_Data_LPT->Shape_DO_1->Brush->Color=clLime;
       }
     else
         {
          B1C = 0;
          AQ_Data_LPT->Shape_DO_1->Brush->Color=clBlack;
         }

 mask = 0x01;

 x = Inp32(REGISTER);
 y = ( x & mask );

 if ( y == 1 )
   {
    B1D = 1;
    AQ_Data_LPT->Shape_DO_2->Brush->Color = clLime;
   }
 else
     {
      B1D = 0;
      AQ_Data_LPT->Shape_DO_2->Brush->Color = clBlack;
     }

 mask = 0x02;

 x = Inp32(REGISTER);
 y = ( ( x & mask ) >> 1 );

 if ( y == 1 )
   {
    B2D = 1;
    AQ_Data_LPT->Shape_DO_3->Brush->Color = clYellow;
   }
 else
     {
      B2D = 0;
      AQ_Data_LPT->Shape_DO_3->Brush->Color = clBlack;
     }

 mask = 0x04;

 x = Inp32(REGISTER);
 y =  ( ( x & mask ) >> 2 );

 if ( y == 1 )
   {
    B3D = 1;
    AQ_Data_LPT->Shape_DO_4->Brush->Color = clYellow;
   }
 else
     {
      B3D = 0;
      AQ_Data_LPT->Shape_DO_4->Brush->Color = clBlack;
     }

 mask = 0x08;

 x = Inp32(REGISTER);
 y =  ( ( x & mask ) >> 3 );

 if ( y == 1 )
   {
    B4D = 1;
    AQ_Data_LPT->Shape_DO_5->Brush->Color = clRed;
   }
 else
     {
      B4D = 0;
      AQ_Data_LPT->Shape_DO_5->Brush->Color = clBlack;
     }

 mask = 0x10;

 x = Inp32(REGISTER);
 y =  ( ( x & mask ) >> 4 );

 if ( y == 1 )
   {
    B5D = 1;
    AQ_Data_LPT->Shape_DO_6->Brush->Color = clRed;
   }
 else
     {
      B5D = 0;
      AQ_Data_LPT->Shape_DO_6->Brush->Color = clBlack;
     }

 mask = 0x20;

 x = Inp32(REGISTER);
 y = ( ( x & mask ) >> 5 );

 if ( y == 1 )
   {
    B6D = 1;
    AQ_Data_LPT->Shape_DO_7->Brush->Color = clRed;
   }
 else
     {
      B6D = 0;
      AQ_Data_LPT->Shape_DO_7->Brush->Color = clBlack;
     }

 mask = 0x40;

 x = Inp32(REGISTER);
 y = ( ( x & mask ) >> 6 );

 if ( y == 1 )
   {
    B7D = 1;
    AQ_Data_LPT->Shape_DO_8->Brush->Color = clRed;
   }
 else
     {
      B7D = 0;
      AQ_Data_LPT->Shape_DO_8->Brush->Color = clBlack;
     }

 mask = 0x80;

 x = Inp32(REGISTER);
 y = ( ( x & mask ) >> 7 );

 if ( y == 1 )
   {
    B8D = 1;
    AQ_Data_LPT->Shape_DO_9->Brush->Color = clYellow;
   }
 else
     {
      B8D = 0;
      AQ_Data_LPT->Shape_DO_9->Brush->Color = clBlack;
     }

 mask = 0x02;

 x = Inp32(REGISTER+2);
 y = ( ( x & mask ) >> 1 );

 if ( y == 0 )
   {
    B2C = 1;
    AQ_Data_LPT->Shape_DO_10->Brush->Color = clYellow;
   }
 else
     {
      B2C = 0;
      AQ_Data_LPT->Shape_DO_10->Brush->Color = clBlack;
     }

 mask = 0x04;

 x = Inp32(REGISTER+2);
 y = ( ( x & mask ) >> 2 );

 if ( y == 1 )
   {
    B3C = 1;
    AQ_Data_LPT->Shape_DO_11->Brush->Color = clLime;
   }
 else
     {
      B3C = 0;
      AQ_Data_LPT->Shape_DO_11->Brush->Color = clBlack;
     }

 mask = 0x08;

 x = Inp32(REGISTER+2);
 y = ( ( x & mask ) >> 3 );

 if ( y == 0 )
   {
    B4C = 1;
    AQ_Data_LPT->Shape_DO_12->Brush->Color = clLime;
   }
 else
     {
      B4C = 0;
      AQ_Data_LPT->Shape_DO_12->Brush->Color = clBlack;
     }
}void __fastcall TAQ_Data_LPT::MaskEdit_REGISTEREnter(TObject *Sender)
{
 ;
}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::ButtonSetClick(TObject *Sender)
{
 //REGISTER = MaskEdit_REGISTER->Text.c_str();
 REGISTER = MaskEdit_REGISTER->Text.ToInt();
 Data = Inp32(REGISTER);
 LabelHexValueData->Caption = Data;
 Control = Inp32(REGISTER+1);
 LabelHexValueControl->Caption = Control;
 Status = Inp32 (REGISTER+2);
 LabelHexValueStatus->Caption = Status;
 Label0x379->Caption = "0x" + IntToHex(REGISTER + 1, 3);
 Label0x37A->Caption = "0x" + IntToHex(REGISTER + 2, 3); 

 ButtonSet->Enabled=false;
 MaskEdit_REGISTER->Enabled=false;


}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::TimerValuesTimer(TObject *Sender)
{
 LabelHexValueStatus->Caption = "0x" + IntToHex(Status, 2);
 LabelHexValueData->Caption=Data;
 LabelHexValueStatus->Caption=Status;
 LabelHexValueControl->Caption=Control;
}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO1Click(TObject *Sender)
{
 CountDO1++;
 if (CountDO1 == 1)
   {
    Out32(REGISTER,0x00);
    Out32(REGISTER+2,0x0A);
    Button_DO1->Font->Style = TFontStyles() << fsBold;    
   }
    else
        {
         Out32(REGISTER+2,0x0B);
         CountDO1=0;
	 Button_DO1->Font->Style = TFontStyles();
        }

}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO2Click(TObject *Sender)
{
 CountDO2++;
 if (CountDO2 == 1)
   {
    Out32(REGISTER+2,0x0B);
    Out32(REGISTER,0x01);
    Button_DO2->Font->Style = TFontStyles() << fsBold;
   }
    else
        {
         Out32(REGISTER,0x00);
         CountDO2=0;
 	   Button_DO2->Font->Style = TFontStyles();
        }

}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO3Click(TObject *Sender)
{
 CountDO3++;
 if (CountDO3 == 1)
   {
    Out32(REGISTER,0x00);
    Out32(REGISTER,0x02);
    Button_DO3->Font->Style = TFontStyles() << fsBold;
   }
    else
        {
         Out32(REGISTER,0x00);
         CountDO3=0;
         Button_DO3->Font->Style = TFontStyles();
        }
}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO4Click(TObject *Sender)
{
 CountDO4++;
 if (CountDO4 == 1)
   {
    Out32(REGISTER,0x00);
    Out32(REGISTER,0x04);
    Button_DO4->Font->Style = TFontStyles() << fsBold;
   }
    else
        {
         Out32(REGISTER,0x00);
         CountDO4=0;
	 Button_DO4->Font->Style = TFontStyles();
        }
}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO5Click(TObject *Sender)
{
 CountDO5++;
 if (CountDO5 == 1)
   {
    Out32(REGISTER,0x00);
    Out32(REGISTER,0x08);
    Button_DO5->Font->Style = TFontStyles() << fsBold;
   }
    else
        {
         Out32(REGISTER,0x00);
         CountDO5=0;
         Button_DO5->Font->Style = TFontStyles();
        }
}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO6Click(TObject *Sender)
{
 CountDO6++;
 if (CountDO6 == 1)
   {
    Out32(REGISTER,0x00);
    Out32(REGISTER,0x10);
    Button_DO6->Font->Style = TFontStyles() << fsBold;
   }
    else
        {
         Out32(REGISTER,0x00);
         CountDO6=0;
 	 Button_DO6->Font->Style = TFontStyles();
        }
}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO7Click(TObject *Sender)
{
 CountDO7++;
 if (CountDO7 == 1)
   {
    Out32(REGISTER,0x00);
    Out32(REGISTER,0x20);
    Button_DO7->Font->Style = TFontStyles() << fsBold;
   }
    else
        {
         Out32(REGISTER,0x00);
         CountDO7=0;
	 Button_DO7->Font->Style = TFontStyles();
        }
}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO8Click(TObject *Sender)
{
 CountDO8++;
 if (CountDO8 == 1)
   {
    Out32(REGISTER,0x00);
    Out32(REGISTER,0x40);
    Button_DO8->Font->Style = TFontStyles() << fsBold;
   }
    else
        {
         Out32(REGISTER,0x00);
         CountDO8=0;
   	 Button_DO8->Font->Style = TFontStyles();
        }
}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO9Click(TObject *Sender)
{
 CountDO9++;
 if (CountDO9 == 1)
   {
    Out32(REGISTER,0x00);
    Out32(REGISTER,0x80);
    Button_DO9->Font->Style = TFontStyles() << fsBold;
   }
    else
        {
         Out32(REGISTER,0x00);
         CountDO9=0;
	 Button_DO9->Font->Style = TFontStyles();
        }
}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO10Click(TObject *Sender)
{
 CountDO10++;
 if (CountDO10 == 1)
   {
    Out32(REGISTER,0x00);
    Out32(REGISTER+2,0x09);
    Button_DO10->Font->Style = TFontStyles() << fsBold;
   }
    else
        {
         Out32(REGISTER+2,0x0B);
         CountDO10=0;
	 Button_DO10->Font->Style = TFontStyles();
        }


}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO11Click(TObject *Sender)
{
 CountDO11++;
 if (CountDO11 == 1)
   {
    Out32(REGISTER,0x00);
    Out32(REGISTER+2,0x0F);
    Button_DO11->Font->Style = TFontStyles() << fsBold;
   }
    else
        {
         Out32(REGISTER+2,0x0B);
         CountDO11=0;
	 Button_DO11->Font->Style = TFontStyles();
        }
}
//---------------------------------------------------------------------------

void __fastcall TAQ_Data_LPT::Button_DO12Click(TObject *Sender)
{
 CountDO12++;
 if (CountDO12 == 1)
   {
    Out32(REGISTER,0x0B);
    Out32(REGISTER+2,0x03);
    Out32(REGISTER,0x00);
    Button_DO12->Font->Style = TFontStyles() << fsBold;
   }
    else
        {
         Out32(REGISTER+2,0x0B);
         CountDO12=0;
	 Button_DO12->Font->Style = TFontStyles();
        }
}
//---------------------------------------------------------------------------

